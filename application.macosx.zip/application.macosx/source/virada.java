import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class virada extends PApplet {

// IMPORT SOUND LIBRARY VIA SKETCH - IMPORT LIBRARY - SOUND
// WORKS BETTER WITH "PRESENT" MODE (SKETCH - PRESENT), NOT "RUN"

// I'VE BEEN WAITING FOR THIS MOMENT FOR ALL MY LIFE, OH LORD...


SoundFile phil;
PImage bg;

public void setup()
{
  
  background(0);
  frameRate(1);
  noCursor();
  
  textSize(100);
  
  phil = new SoundFile(this, "phil_comp.mp3");
  bg = loadImage("preto.jpg");
}

public void draw()
{
  //bg = loadImage("cara.jpg");
  background(bg);
  
  int hora = hour(); 
  int min = minute();
  int seg = second();
  
  String s_hora = nf(hora, 2);
  String s_min  = nf(min, 2);
  String s_seg  = nf(seg, 2);
  
  int xHora  = (width/2) - 220;
  //int xMin = 55;
  //int xSeg = 100;
  int offset = 150;
  int yText  = (height/2) + 50;
  
  text(s_hora + ":", xHora, yText);
  text(s_min + ":", xHora + offset, yText); 
  text(s_seg, xHora + (offset * 2), yText);
  
  if (hora == 23 && min == 56 && seg == 16) //23:56:16
  {
    phil.play();
    bg = loadImage("cara.jpg");
  }
  
  if (hora == 0 && min == 1 && seg == 40)
  {
    bg = loadImage("preto.jpg");
  }
}

public void mousePressed() //click the mouse to test sound
{
  phil.play();
  bg = loadImage("cara.jpg");
}
  public void settings() {  size(599, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#0A0000", "--stop-color=#cccccc", "virada" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
